"""Chargement du modèle IsolationForest + baseline_stats.json produits par ml/training."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

import joblib
import numpy as np
import sklearn
from resilience_common import get_logger

from ml.shared.features import FEATURE_NAMES, validate_vector

# Logger JSON du contrat (même logger "detector" que app.py) : le warning de dérive doit être
# indexable par Promtail/Loki, pas un message texte brut sur stderr.
log = get_logger("detector")


class ModelLoadError(RuntimeError):
    """Artefacts absents, altérés ou incompatibles avec la définition des features."""


@dataclass
class LoadedModel:
    model: object  # sklearn.ensemble.IsolationForest
    stats: dict

    @property
    def version(self) -> str:
        return self.stats["model_version"]

    @property
    def threshold(self) -> float:
        return float(self.stats["threshold"])

    @property
    def threshold_high(self) -> float | None:
        """Seuil « haut » calibré : au-dessus, une seule fenêtre suffit (pas de confirmation)."""
        value = (self.stats.get("calibration") or {}).get("threshold_high")
        return float(value) if value is not None else None

    @property
    def confirm_windows(self) -> int:
        """Fenêtres consécutives au-dessus du seuil exigées (calibration ; 1 = sans confirmation)."""
        return int((self.stats.get("calibration") or {}).get("confirm_windows", 1))

    @property
    def guardrail_z(self) -> float:
        return float(self.stats["guardrail_z"])

    def score(self, vector: list[float]) -> float:
        """Score d'anomalie dans (0, 1], plus haut = plus anormal (= -score_samples)."""
        validate_vector(vector)
        return float(-self.model.score_samples(np.asarray([vector], dtype=float))[0])


def load_model(model_dir: str | Path) -> LoadedModel:
    d = Path(model_dir)
    model_path, stats_path = d / "model.joblib", d / "baseline_stats.json"
    if not model_path.is_file() or not stats_path.is_file():
        raise ModelLoadError(f"model.joblib / baseline_stats.json introuvables dans {d}")
    stats = json.loads(stats_path.read_text())

    if stats.get("feature_names") != list(FEATURE_NAMES):
        raise ModelLoadError(
            "feature_names du modèle différents de ml.shared.features.FEATURE_NAMES : ré-entraîner"
        )
    # joblib = pickle : on ne désérialise un artefact que s'il correspond au hash publié
    # par le training (détecte altération/remplacement du fichier).
    expected = stats.get("model_sha256")
    actual = hashlib.sha256(model_path.read_bytes()).hexdigest()
    if expected != actual:
        raise ModelLoadError("model.joblib ne correspond pas au sha256 de baseline_stats.json")

    # Dérive de version scikit-learn : un modèle entraîné avec une autre version peut, une fois
    # rechargé, produire des scores silencieusement différents. On n'échoue pas (le sha256 garantit
    # déjà l'intégrité de l'artefact) mais on journalise un avertissement explicite (#23).
    # `sklearn_version` est enregistré sous stats["training"] par ml/training/train.py
    # (fallback au niveau racine par robustesse).
    trained_with = (stats.get("training") or {}).get("sklearn_version") or stats.get(
        "sklearn_version"
    )
    if trained_with and trained_with != sklearn.__version__:
        log.warning(
            "scikit-learn %s installé mais modèle entraîné avec %s : scores potentiellement "
            "différents, ré-entraîner ou aligner les versions (ml/*/requirements.txt)",
            sklearn.__version__,
            trained_with,
            extra={"event": "model_version_drift"},
        )

    payload = joblib.load(model_path)
    return LoadedModel(model=payload["model"], stats=stats)
