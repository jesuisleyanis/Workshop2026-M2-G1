import { describe, expect, it } from 'vitest'
import { amountToInput, formatDate, formatIban, formatMoney, maskIban, shortIban } from './format'

describe('format', () => {
  it('formate les montants en EUR fr-FR', () => {
    expect(formatMoney(1250.5)).toMatch(/1\s?250,50\s?€/)
  })
  it('regroupe et abrège les IBAN', () => {
    expect(formatIban('FR7630001007941234567890185')).toBe('FR76 3000 1007 9412 3456 7890 185')
    expect(shortIban('FR76 3000 1007 9412')).toBe('FR76 … 9412')
    expect(shortIban('FR-1')).toBe('FR-1')
  })
  it('date absente ou illisible => tiret', () => {
    expect(formatDate('')).toBe('—')
    expect(formatDate('pas-une-date')).toBe('—')
  })
  it('montant -> valeur de champ', () => {
    expect(amountToInput(1250.5)).toBe('1250,50')
  })
})

describe('maskIban (#45)', () => {
  it('garde pays + clé, code banque et 4e groupe ; client et tiers restent distincts', () => {
    expect(maskIban('FR76 0000 0000 0001 0000 0000 000')).toBe('FR76 0000 •••• 0001 •••• •••• •••')
    expect(maskIban('FR76 9999 0000 0001 0000 0000 000')).toBe('FR76 9999 •••• 0001 •••• •••• •••')
    expect(maskIban('FR7612345678901234567890')).toBe('FR76 1234 •••• 9012 •••• ••••')
    expect(maskIban('FR76 A1')).toBe('FR76 A1')
  })
})
